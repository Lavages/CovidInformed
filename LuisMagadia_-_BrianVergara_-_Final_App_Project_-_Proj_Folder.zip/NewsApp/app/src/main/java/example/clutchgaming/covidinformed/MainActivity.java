package example.clutchgaming.covidinformed;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import example.clutchgaming.covidinformed.helpers.Adapter;
import example.clutchgaming.covidinformed.model.Articles;
import example.clutchgaming.covidinformed.model.Headlines;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


    public class MainActivity extends AppCompatActivity {
        RecyclerView recyclerView;
        Adapter adapter;
        final  String API_KEY="0a6cd02777ce458ea4c004768cfc9659";
        Button button;
        ImageButton floatingActionButton;
        List<Articles> articles=new ArrayList<>();




        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            recyclerView=(RecyclerView)findViewById(R.id.recyclerView);

            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            TextView tvv = (TextView) findViewById(R.id.top);
            Typeface face = Typeface.createFromAsset(getAssets(),
                    "fonts/Slimlines2.ttf");
            tvv.setTypeface(face);

            final String country= "ph";
            final String about= "covid";
            floatingActionButton=(ImageButton)findViewById(R.id.floating);
            floatingActionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(MainActivity.this,Intro.class);
                    startActivity(intent);
                }
            });

            retrieveJson(country, about, API_KEY);

        }

        public  void retrieveJson(String country, String about, String apiKey)
        {
            Call<Headlines> call= Client.getInstance().getApi().getHeadlines(country, about, apiKey);
            call.enqueue(new Callback<Headlines>() {
                @Override
                public void onResponse(Call<Headlines> call, Response<Headlines> response) {
                    if (response.isSuccessful() && response.body().getArticles()!=null){
                        articles.clear();
                        articles=response.body().getArticles();

                        adapter = new Adapter(MainActivity.this, articles);
                        recyclerView.setAdapter(adapter);
                    }
                }

                @Override
                public void onFailure(Call<Headlines> call, Throwable t) {

                    Toast.makeText(MainActivity.this,"Error Occured, Please try again.",Toast.LENGTH_SHORT).show();
                }
            });
        }


        public String getCountry()
        {
            Locale locale=Locale.getDefault();
            String country=locale.getCountry();
            return country.toLowerCase();
        }
    }

